#include <string>
#pragma once

void showInterface(); //Print the menu.

void interfaceOptions(std::string serverAddress,int portAddr);

void showServerData(std::string serverAddress, int portAddr);

void clear_screen();